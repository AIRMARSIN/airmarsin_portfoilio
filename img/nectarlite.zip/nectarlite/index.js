let educateB = document.getElementById("educate-btn")

educateB.textContent = "Educate "

educateB.addEventListener("click",  function() {
    console.log("Button Clicked")
})

// add onclick() to the button in index.html
// function educateBtn() {
//     console.log("Button Clicked!")
// }